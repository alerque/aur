# brave-patches
Patches needed to build brave with GCC and/or libstdc++.

Using with https://github.com/stha09/chromium-patches
