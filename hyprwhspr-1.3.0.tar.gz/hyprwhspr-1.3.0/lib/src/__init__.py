"""
hyprwhspr source modules
Core functionality for voice dictation application
"""
